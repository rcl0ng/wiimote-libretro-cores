# Release assets

Wiimote v1.0.0 packaging revision 2 separates installation files from full modified source. Upload both Wiimote_Libretro_v1.0.0_Windows_x64.zip and Wiimote_Libretro_v1.0.0_Source.zip plus Wiimote_Libretro_v1.0.0_SHA256SUMS.txt to the existing release. Replace the old combined Windows asset and old checksum. Keep both matching source and Windows assets available. GitHub automatic Source code archives contain the repository tree only. Full source is a separately attached asset.
